//  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
// import dotenv from 'dotenv';
// import OpenAI from "openai";
// dotenv.config()

// const openai = new OpenAI({
//     apiKey: process.env.API_KEY,
// });

// async function main() {
//   const completion = await openai.chat.completions.create({
//     messages: [{role: "system", content: "can you tell me what is the difference between the node js and normal vanilla js"}],
//     model: "gpt-3.5-turbo",
//   });

//   console.log(completion.choices);
// }
// main();






// const dotenv = require('dotenv');
// // const fetch = require('node-fetch');
// dotenv.config();
// const apiKey = process.env.API_KEY;
// const openai = require('openai');
// const openaiInstance = new openai.default({
//     apiKey: apiKey
// });

// const express = require('express');
// const bodyparser = require('body-parser');
// const mysql = require('mysql');
// const port = process.env.PORT || 2001;
// const app = express();
// const cors = require('cors');

// app.use(bodyparser.json({ limit: "100mb" }));
// app.use(bodyparser.urlencoded({ limit: "100mb", extended: true }));
// app.use(express.json());
// app.use(cors());


// app.post("/chat", (req, res) => {
//     // console.log(req.body.message); // user message
//     const message = req.body.message;

//     const output = main(message);
//     const result = output[0].message.content;
//     res.json(result);
// })


// function main(InputMessage) {
//     const requestBody = {
//         messages: [{ role: "system", content: InputMessage }],
//         model: "gpt-3.5-turbo"
//     };

//     return fetch('https://api.openai.com/v1/chat/completions', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//             'Authorization': `Bearer ${apiKey}`
//         },
//         body: JSON.stringify(requestBody)
//     })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Failed to fetch response from API');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data.choices);
//         })
//         .catch(error => {
//             console.error('Error:', error);
//         });
// }

// app.listen(port, () => {
//     console.log(`Listening ... ${port}`);
// })


const dotenv = require('dotenv');
const express = require('express');
const bodyParser = require('body-parser');
const port = process.env.PORT || 2001;
const app = express();
const cors = require('cors');

dotenv.config();
const apiKey = process.env.API_KEY;

app.use(bodyParser.json({ limit: "100mb" }));
app.use(bodyParser.urlencoded({ limit: "100mb", extended: true }));
app.use(express.json());
app.use(cors());

app.post("/chat", async (req, res) => {
    console.log(req.body.message);
    const message = req.body.message;
    try {
        const result = await main(message);
        console.log(result[0].message.content);
        res.json(result[0].message.content);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
})

async function main(inputMessage) {
    const requestBody = {
        messages: [{ role: "system", content: inputMessage }],
        model: "gpt-3.5-turbo"
    };

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
        throw new Error('Failed to fetch response from API');
    }

    const data = await response.json();
    // console.log(data.choices);
    return data.choices;
}

app.listen(port, () => {
    console.log(`Listening ... ${port}`);
});
