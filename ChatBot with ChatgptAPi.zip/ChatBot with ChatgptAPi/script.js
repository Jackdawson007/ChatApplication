// const userInput = document.getElementById('user-input');
// const chatBox = document.getElementById('chat-box');

// function sendMessage() {
//     const message = userInput.value.trim();

//     if (message) {
//         console.log('User message:', message);
//         appendMessage(`You ${message}`)

//         fetch("http://localhost:2001/chat", {
//             method: "POST",
//             mode: "cors",
//             headers: {
//                 "Content-Type": "application/json"
//             },
//             body: JSON.stringify({ message })
//         })
//             .then((res) => res.json())
//             .then((data) => {
//                 console.log(data);
//             })
//             .catch((err) => console.log(err))

//         userInput.value = '';
//     }
// }


// function appendMessage(message, role) {
//     // Create a message element
//     const messageElement = document.createElement('div');
//     messageElement.classList.add('message');
//     messageElement.classList.add(role + '-message');
//     messageElement.textContent = message;

//     // Append message to chat box
//     chatBox.appendChild(messageElement);

//     // Scroll chat box to bottom
//     chatBox.scrollTop = chatBox.scrollHeight;
// }







const userInput = document.getElementById('user-input');
const chatBox = document.getElementById('chat-box');

async function sendMessage() {
    const message = userInput.value.trim();
    userInput.value = '';
    
    if (message) {
        console.log('User message:', message);
        appendMessage(`YOU : ${message}`);

        try {
            const response = await fetch("http://172.17.22.146:2001/chat", {
                method: "POST",
                mode: "cors",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ message })
            });

            if (response.ok) {
                const data = await response.json();
                console.log(data);
                appendMessage(`BOT : ${data}`)
            } else {
                console.error('Error fetching data:', response.status);
            }
        } catch (err) {
            console.error('Error communicating with the server:', err.message);
        }
    }
}

function appendMessage(message, role) {
    // Create a message element
    const messageElement = document.createElement('p');
    messageElement.classList.add('message');
    messageElement.classList.add(role + '-message');
    messageElement.textContent = message;

    // Append message to chat box
    chatBox.appendChild(messageElement);

    // Scroll chat box to bottom
    chatBox.scrollTop = chatBox.scrollHeight;
}
